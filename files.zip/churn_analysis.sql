-- =====================================================================
-- Retail Banking Customer Attrition: SQL analysis (SQLite)
-- Database : database/churn.db   Table: customers (10,000 rows)
-- Source   : data/clean/Churn_Modelling_clean.csv
-- Note     : Exited = 1 means the customer left, 0 means retained.
--            SUM(Exited) counts exits, 100.0 * SUM / COUNT gives the rate.
--            100.0 (not 100) forces decimal division in SQLite.
-- =====================================================================

-- Q1. Overall customer count and attrition rate
SELECT COUNT(*)                                 AS total_customers,
       SUM(Exited)                              AS exited_customers,
       ROUND(100.0 * SUM(Exited) / COUNT(*), 2) AS attrition_pct
FROM customers;

-- Q2. Attrition by geography
SELECT Geography,
       COUNT(*)                                 AS customers,
       SUM(Exited)                              AS exited,
       ROUND(100.0 * SUM(Exited) / COUNT(*), 2) AS attrition_pct
FROM customers
GROUP BY Geography
ORDER BY attrition_pct DESC;

-- Q3. Attrition by age group (CASE WHEN builds the groups)
SELECT CASE WHEN Age < 30 THEN '1. Under 30'
            WHEN Age < 40 THEN '2. 30-39'
            WHEN Age < 50 THEN '3. 40-49'
            WHEN Age < 60 THEN '4. 50-59'
            ELSE '5. 60+' END                   AS age_group,
       COUNT(*)                                 AS customers,
       SUM(Exited)                              AS exited,
       ROUND(100.0 * SUM(Exited) / COUNT(*), 2) AS attrition_pct
FROM customers
GROUP BY age_group
ORDER BY age_group;

-- Q4. Attrition by tenure
SELECT Tenure,
       COUNT(*)                                 AS customers,
       SUM(Exited)                              AS exited,
       ROUND(100.0 * SUM(Exited) / COUNT(*), 2) AS attrition_pct
FROM customers
GROUP BY Tenure
ORDER BY Tenure;

-- Q5. Attrition by number of products (groups 3 and 4 are small)
SELECT NumOfProducts,
       COUNT(*)                                 AS customers,
       SUM(Exited)                              AS exited,
       ROUND(100.0 * SUM(Exited) / COUNT(*), 2) AS attrition_pct
FROM customers
GROUP BY NumOfProducts
ORDER BY NumOfProducts;

-- Q6. Attrition by activity status
SELECT CASE WHEN IsActiveMember = 1 THEN 'Active' ELSE 'Inactive' END AS status,
       COUNT(*)                                 AS customers,
       SUM(Exited)                              AS exited,
       ROUND(100.0 * SUM(Exited) / COUNT(*), 2) AS attrition_pct
FROM customers
GROUP BY IsActiveMember
ORDER BY IsActiveMember DESC;

-- Q7. Balance: exited versus retained
SELECT CASE WHEN Exited = 1 THEN 'Exited' ELSE 'Retained' END AS status,
       COUNT(*)                                                AS customers,
       ROUND(AVG(Balance), 2)                                  AS avg_balance,
       ROUND(100.0 * SUM(CASE WHEN Balance = 0 THEN 1 ELSE 0 END) / COUNT(*), 2) AS pct_zero_balance,
       ROUND(AVG(CASE WHEN Balance > 0 THEN Balance END), 2)   AS avg_balance_nonzero
FROM customers
GROUP BY Exited
ORDER BY Exited;

-- Q8. Attrition by balance band
SELECT CASE WHEN Balance = 0      THEN 'Zero'
            WHEN Balance < 100000 THEN '0-100k'
            WHEN Balance < 150000 THEN '100-150k'
            ELSE '150k+' END                    AS balance_band,
       COUNT(*)                                 AS customers,
       SUM(Exited)                              AS exited,
       ROUND(100.0 * SUM(Exited) / COUNT(*), 2) AS attrition_pct
FROM customers
GROUP BY balance_band
ORDER BY MIN(Balance);

-- Q9. Attrition by age group and activity status (CTE)
WITH banded AS (
    SELECT CASE WHEN Age < 40 THEN 'Under 40'
                WHEN Age < 50 THEN '40-49'
                ELSE '50+' END AS age_group,
           IsActiveMember, Exited
    FROM customers
)
SELECT age_group,
       CASE WHEN IsActiveMember = 1 THEN 'Active' ELSE 'Inactive' END AS status,
       COUNT(*)                                 AS customers,
       SUM(Exited)                              AS exited,
       ROUND(100.0 * SUM(Exited) / COUNT(*), 2) AS attrition_pct
FROM banded
GROUP BY age_group, IsActiveMember
ORDER BY age_group, IsActiveMember DESC;

-- Q10. Zero-balance customers by geography (data check)
SELECT Geography,
       COUNT(*)                                                      AS customers,
       SUM(CASE WHEN Balance = 0 THEN 1 ELSE 0 END)                  AS zero_balance,
       ROUND(100.0 * SUM(CASE WHEN Balance = 0 THEN 1 ELSE 0 END) / COUNT(*), 2) AS pct_zero_balance
FROM customers
GROUP BY Geography;

-- Q11. Candidate segments for further investigation (min 100 customers)
SELECT Geography,
       CASE WHEN Age >= 40 THEN '40+' ELSE 'Under 40' END AS age_group,
       CASE WHEN IsActiveMember = 1 THEN 'Active' ELSE 'Inactive' END AS status,
       COUNT(*)                                 AS customers,
       SUM(Exited)                              AS exited,
       ROUND(100.0 * SUM(Exited) / COUNT(*), 2) AS attrition_pct
FROM customers
GROUP BY Geography, age_group, status
HAVING COUNT(*) >= 100
ORDER BY attrition_pct DESC;
