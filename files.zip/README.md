# Retail Banking Customer Attrition and Behaviour Analysis

## Business question
Which customer segments have higher attrition, and how do age, activity status and number of products combine to explain it? The project identifies segments worth investigating and suggests actions the bank could consider. All findings are associations, not causes.

## Dataset
- **File:** Churn_Modelling.csv (10,000 rows, 14 columns), widely circulated on Kaggle.
- **Source link:** https://www.kaggle.com/datasets/shrutimechlearn/churn-modelling (the same file is listed under other Kaggle uploads, for example https://www.kaggle.com/datasets/filippoo/deep-learning-az-ann).
- **Provenance:** Not documented. The sources do not say whether the data is synthetic, anonymised or based on real banking records, and the original upload cannot be verified. This project does not assume either.
- **Time period:** Not documented. Attrition rates cannot be benchmarked.
- **Column meanings are inferred from column names** (no data dictionary exists).

| Column | Meaning (inferred) |
|---|---|
| RowNumber | Row sequence (dropped in cleaning) |
| CustomerId | Unique customer identifier |
| Surname | Customer surname (dropped in cleaning) |
| CreditScore | Credit score |
| Geography | France, Germany or Spain |
| Gender | Female or Male |
| Age | Age in years |
| Tenure | Years with the bank (unit not documented) |
| Balance | Account balance (currency not documented) |
| NumOfProducts | Number of bank products held (1 to 4) |
| HasCrCard | 1 if the customer has a credit card |
| IsActiveMember | 1 if flagged active (definition not documented) |
| EstimatedSalary | Estimated salary (currency not documented) |
| Exited | Target: 1 = left the bank, 0 = retained |

## Data checks
No missing values, no duplicate rows, no duplicate CustomerId. `Exited` is binary and suitable as an attrition target (2,037 exited, 7,963 retained). Two items flagged: 36.2% of customers have zero balance (all in France or Spain), and only 266 and 60 customers hold 3 and 4 products.

## Methodology
1. **Data understanding:** inspect shape, types, missing values, duplicates and distributions.
2. **Preparation:** drop `RowNumber` and `Surname` only. No rows removed, no values changed. The original file is kept in `data/raw`.
3. **SQL (SQLite):** 11 queries in `sql/churn_analysis.sql` using GROUP BY, CASE WHEN, aggregates and a CTE.
4. **Python:** pandas, NumPy and Matplotlib for rates, segmentation and charts. A SQL versus pandas cross-check confirms both agree.
5. **Interpretation:** each finding separates observed facts, interpretation, hypotheses and possible actions.

Attrition rate = exited customers / all customers in the group. Group sizes are always shown next to rates.

## Key findings (observed)
- Overall attrition: 20.37% (2,037 of 10,000).
- Age: 7.56% under 30, 10.88% at 30-39, 30.79% at 40-49, 56.04% at 50-59, 27.95% at 60+.
- Activity: inactive 26.85% versus active 14.27%, higher in every age band.
- Products: 27.71% (1), 7.58% (2), 82.71% (3, n=266), 100% (4, n=60).
- Geography: Germany 32.44%, Spain 16.67%, France 16.15%. Germany has no zero-balance customers.
- Balance: the average-balance gap between exited and retained customers comes mainly from the share of zero-balance accounts.
- Tenure: no clear pattern (17.22% to 23.00%).

## Recommendations (to investigate, not proven causes)
1. Pilot re-engagement for inactive customers aged 40+ (1,880 customers, 49.36% attrition) with a control group.
2. Review the sales and servicing journey for 3 and 4 product customers.
3. Validate the Germany data, then investigate the market and proposition.
4. Test a second-product offer for single-product customers as a controlled experiment.
5. Capture exit dates and reasons so attrition can be explained.

## Assumptions and limitations
- Provenance, time period and column definitions are not documented.
- Single snapshot, no exit reasons, product detail or channel data.
- No significance testing. Segments overlap, and small groups should be read with caution.
- No financial impact is estimated. The analysis does not predict which individual customers will leave.

## Folder structure
```
churn_project/
  README.md
  data/raw/Churn_Modelling.csv            original, unchanged
  data/clean/Churn_Modelling_clean.csv    RowNumber and Surname removed
  database/churn.db                       SQLite, table: customers
  sql/churn_analysis.sql                  11 analytical queries
  notebook/churn_analysis.ipynb           full analysis with outputs
  charts/                                 5 PNG charts
  presentation/Churn_Attrition_Executive_Summary.pptx   5 slides
```

## How to reproduce
Install pandas, numpy and matplotlib. Open `notebook/churn_analysis.ipynb` and run all cells from the notebook folder. The SQL script can be run in any SQLite client against `database/churn.db`.
